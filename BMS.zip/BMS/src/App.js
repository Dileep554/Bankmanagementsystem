import "./App.css";
//import { Register1 } from "./Components/AboutRegister/Register1";
import Login1 from "./Components/aboutLogin/Login1";
//import { Deposit } from "./Components/AboutDeposit/Deposit";
//import HeaderComponent from "./Components/headerComponent/HeaderComponent";
//import ApplyLoan from "./Components/aboutApplyLoanComponent/ApplyLoan";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import LoginPage from "./Components/LoginPage";
import RegisterPage from "./Components/RegisterPage";
import ApplyLoanPage from "./Components/ApplyLoanPage";
import MainPage from "./Components/MainPage";
import DepositPage from "./Components/DepositPage";
import { useState } from "react";
import ProfilePage from "./Components/ProfilePage";
import EditProfilePage from "./Components/EditProfilePage";
//import Profile from "./Components/editProfileComponent/Profile";

function App() {
  const [userdata, setUserdata] = useState({});
  const [authenticated, setAuthenticated] = useState(false);
  return (
    <div class="App">
      <Router>
        <Routes>
          <Route path="/" element={<MainPage />} />
        
          <Route
            path="/loginPage"
            element={
              <LoginPage
                userdata={userdata}
                setUserdata={setUserdata}
                authenticated={authenticated}
                setAuthenticated={setAuthenticated}
              />
            }
          
          />
          <Route path="/registerPage" element={<RegisterPage />} />
          <Route
            path="/applyLoanPage"
            element={
              <ApplyLoanPage
                userdata={userdata}
                authenticated={authenticated}
                setAuthenticated={setAuthenticated}
              />
            }
          />
          <Route
            path="/depositPage"
            element={
              <DepositPage
                userdata={userdata}
                authenticated={authenticated}
                setAuthenticated={setAuthenticated}
              />
            }
          />
            <Route 
            path="/editProfilePage"
            element ={
              <EditProfilePage
                userdata={userdata}
                setUserdata={setUserdata}
                authenticated={authenticated}
                setAuthenticated={setAuthenticated}
                />
            
              }
              />
               <Route 
            path="/profilePage"
            element ={
              <ProfilePage
                userdata={userdata}
                setUserdata={setUserdata}
                authenticated={authenticated}
                setAuthenticated={setAuthenticated}
                />
            
              }
              />
              
              

        </Routes>
      </Router>

    </div>
  );
}

export default App;
