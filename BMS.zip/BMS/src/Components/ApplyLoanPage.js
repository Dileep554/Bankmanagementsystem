import HeaderComponent from "./headerComponent/HeaderComponent";
import ApplyLoan from "./aboutApplyLoanComponent/ApplyLoan";
import Login from "./aboutLogin/Login";

export default function ApplyLoanPage(props) {
  const { authenticated, setAuthenticated, userdata } = props;
  //const {authenticated, setAuthenticated, userdata, setUserdata} = props
  console.log("authentication in applyloan", authenticated);
  return (
    <div>
      <HeaderComponent
        authenticated={authenticated}
        setAuthenticated={setAuthenticated}
      />
      {authenticated ? <ApplyLoan userdata={userdata} /> : <Login />}
    </div>
  );
}
