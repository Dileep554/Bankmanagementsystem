import Deposit from "./aboutDeposit/Deposit";
import Login from "./aboutLogin/Login";
import HeaderComponent from "./headerComponent/HeaderComponent";

export default function DepositPage(props) {
  const { authenticated, setAuthenticated, userdata } = props;
  return (
    <div>
      <HeaderComponent
        authenticated={authenticated}
        setAuthenticated={setAuthenticated}
      />
      {authenticated ? <Deposit userdata={userdata} /> : <Login />}
    </div>
  );
}
