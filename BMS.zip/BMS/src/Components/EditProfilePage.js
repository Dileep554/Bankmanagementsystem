
import HeaderComponent from "./headerComponent/HeaderComponent";
import { useState } from "react";
import EditProfile from "./editProfileComponent/EditProfile";
import Login from "./aboutLogin/Login";

export default function EditProfilePage(props){
    // const [authenticated,setAuthenticated] = useState(false);
  const { authenticated, setAuthenticated, userdata,setUserdata } = props;

    console.log("userdata:",userdata)
    console.log(authenticated)
    return(

        <div>
            <HeaderComponent authenticated={authenticated} setAuthenticated={setAuthenticated} userdata={userdata}/>
            
            {authenticated ? <EditProfile authenticated={authenticated} setAuthenticated={setAuthenticated} userdata={userdata} setUserdata={setUserdata}/> : <Login />}
        </div>
    );
}