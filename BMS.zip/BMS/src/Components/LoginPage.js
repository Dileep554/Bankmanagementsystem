import Login from "./aboutLogin/Login";
import HeaderComponent from "./headerComponent/HeaderComponent";
import { useState } from "react";

export default function LoginPage(props){
    // const [authenticated,setAuthenticated] = useState(false);
  const { authenticated, setAuthenticated, userdata,setUserdata } = props;

    console.log("userdata:",userdata)
    return(

        <div>
            <HeaderComponent authenticated={authenticated} setAuthenticated={setAuthenticated} userdata={userdata}/>
            <Login authenticated={authenticated} setAuthenticated={setAuthenticated} userdata={userdata} setUserdata={setUserdata}/>

        </div>
    );
}