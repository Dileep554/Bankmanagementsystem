import HeaderComponent from "./headerComponent/HeaderComponent";
import Login1 from "./aboutLogin/Login1";

function MainPage(){

    return(
        <div>
            <HeaderComponent/>
            <h1>Welcome</h1>
            {/* <Login1 /> */}
        </div>

    );
}

export default MainPage;