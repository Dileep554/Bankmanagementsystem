
import HeaderComponent from "./headerComponent/HeaderComponent";
import { useState } from "react";
import Profile from "./editProfileComponent/Profile";
import Login from "./aboutLogin/Login";

export default function ProfilePage(props){
    // const [authenticated,setAuthenticated] = useState(false);
  const { authenticated, setAuthenticated, userdata,setUserdata } = props;

    console.log("userdata:",userdata)
    console.log(authenticated)
    return(

        <div>
            <HeaderComponent authenticated={authenticated} setAuthenticated={setAuthenticated} userdata={userdata}/>
            
            {authenticated ? <Profile authenticated={authenticated} setAuthenticated={setAuthenticated} userdata={userdata} setUserdata={setUserdata}/> : <Login />}
        </div>
    );
}