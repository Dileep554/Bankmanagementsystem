import HeaderComponent from "./headerComponent/HeaderComponent";
import Register from "./aboutRegister/Register";
function RegisterPage() {
  return (
    <div>
      <HeaderComponent />
      <Register />
    </div>
  );
}
export default RegisterPage;
