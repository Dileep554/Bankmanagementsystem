import React, { useEffect } from "react";
import axios, { AxiosError } from "axios";
import { useState } from "react";
import SelectComponent from "../selectComponent/SelectComponent";
import { MDBContainer, MDBInput, MDBBtn } from "mdb-react-ui-kit";
import {
  FormControlLabel,
  FormLabel,
  InputLabel,
  Radio,
  RadioGroup,
} from "@mui/material";
import { FormControl, MenuItem, Select } from "@mui/base";
import { Box } from "@mui/system";

export function ApplyLoan(props) {
  const [todayDate, setTodayDate] = useState(new Date());
  const { userdata } = props;
  const [message, setMessage] = useState();
  const initialValues = {
    loanType: "",
    loanInformation: {},
    loanAmount: "",
    date: "",
    rateOfInterest: "",
    durationOfLoan: "",
  };
  const [inputField, setInputField] = useState({
    // loanId: "",
    // customerId: "",
    loanType: "",
    loanInformation: {
      // courseFee: "",
      // course: "",
      // fatherName: "",
      // fatherOccupation: "",
      // fatherAnnualIncome: "",
      // annualIncome: "",
      // companyName: "",
      // designation: "",
      // totalExp: "",
      // currentCompanyExp: "",
    },
    loanAmount: "",
    date: "",
    rateOfInterest: "",
    durationOfLoan: "",
  });

  const [loanType, setLoanType] = useState("");
  const allLoanTypes = ["Education Loan", "Personal Loan", "Home Loan"];
  const [duration, setDuration] = useState("");
  const allDurations = [5, 10, 15, 20];
  const [loanValue, setLoanValue] = useState("");
  const [selectedLoanType, setSelectedLoanType] = useState("");
  const [loanSuccess, setLoanSuccess] = useState(false);


  const inputsHandler = (e) => {
    const { name, value } = e.target;
    setInputField((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setLoanValue(value);

    inputField.loanInformation[name] = value;
  };

  const handleLoanType = (value) => {
    setLoanType(value);
    //console.log(value, loanType);
    inputField.loanType = value;
  };

  const submitButton = () => {
    console.log(inputField);
    setLoanSuccess(true);
    axios
      .post(
        `http://localhost:8081/applyLoan/${userdata.customerId}`,
        inputField
      )
      .then((data) => {
        console.log(data.data);
        setInputField(initialValues);
        setMessage(data.data);
      })
      .catch((error) => {
        // console.log(AxiosError);
        // console.log(AxiosError.message);
      });
  };

  useEffect(() => {
    if (loanType == "Education Loan") {
      setSelectedLoanType(educationLoanDataInputs);
      
    } else {
      setSelectedLoanType(personalLoanDataInputs);
    }
  }, [loanType]);
  useEffect(() => {
    console.log("duration", duration);
    inputField.durationOfLoan = duration;
  }, [duration]);
  //let selectedItems = Object.entries(selectedLoanType);
  useEffect(()=>{
    const dates = todayDate.getDate();
    const mon = todayDate.getMonth();
    const year = todayDate.getFullYear();
    inputField.date = `${dates}/${mon}/${year}`;
  },[todayDate]);

  useEffect(() =>{
    console.log(loanType);
    if(loanType == "Education Loan"){
      inputField.rateOfInterest=8;
    }
    else if(loanType == "Home Loan"){
      inputField.rateOfInterest=10;
    }
    else if(loanType == "Personal Loan"){
      inputField.rateOfInterest=12;
    }
  },[loanType]);


  const educationLoanDataInputs = {
    courseFee: "Course Fee",
    course: "Course",
    fatherName: "Father Name",
    fatherOccupation: "Father Occupation",
    fatherAnnualIncome: "Father Annual Income",
  };

  //let selectedItems = Object.entries(educationLoanDataInputs);

  const personalLoanDataInputs = {
    annualIncome: "Annual Income",
    companyName: "Company Name",
    designation: "Designation",
    totalExp: "Total Exp",
    currentCompanyExp: "Exp with Current Company",
  };

  return (
    // <>
    //   {!loanSuccess ? (
    <>
      <MDBContainer className="p-3 my-5 d-flex flex-column w-50">
        <SelectComponent
          type={loanType}
          setType={handleLoanType}
          allTypes={allLoanTypes}
          labelType={"Loan Type"}
        />

        {loanType == "" ? (
          <></>
        ) : (
          <div className="border border-dark mt-4 pt-4">
            {Object.entries(selectedLoanType)?.map(([key, loan]) => (
              <MDBInput
                wrapperClass="mb-4"
                type="text"
                name={key}
                onChange={(e) => handleChange(e)}
                placeholder={loan}
                value={inputField.loanInformation.key}
              />
            ))}
          </div>
        )}

        {/* 

  
{sortItems?.map(([key, sortItem] = entry) => (

            <option value={key}>{sortItem}</option>

          ))} */}
        <MDBInput
          className="mt-4"
          wrapperClass="mb-4"
          id="form4"
          type="text"
          name="loanAmount"
          onChange={inputsHandler}
          placeholder="Loan Amount"
          value={inputField.loanAmount}
        />
        <MDBInput
          wrapperClass="mb-4"
          type="text"
          name="date"
          onChange={inputsHandler}
          // placeholder="Date"
          value={inputField.date}
          disabled
        />
        <MDBInput
          wrapperClass="mb-4"
          id="form6"
          type="number"
          name="rateOfInterest"
          onChange={inputsHandler}
          placeholder="Rate Of interest"
          value={inputField.rateOfInterest}
          disabled
        />

        {/* <RateSelectComponent 
             rate={rate}
             setRate={handleRate}
             allRates={allRates}
             /> */}
        <div  wrapperClass="mb-4">
        <SelectComponent
        
          type={duration}
          setType={setDuration}
          allTypes={allDurations}
          labelType={"Duration Of Loan"}
        />
        </div>


        {/* <div className="d-flex justify-content-between mx-3 mb-4">
        <MDBCheckbox name='flexCheck' value='' id='flexCheckDefault' label='Remember me' />
        <a href="!#">Forgot password?</a>
      </div> */}
        <MDBBtn className="mb-4" onClick={submitButton}>
          Apply Loan
        </MDBBtn>

        <div>{!loanSuccess ? <></> : <div className="">{message}</div>}</div>
      </MDBContainer>
    </>
    //   ) : (
    //     <>
    //       <div>
    //         <div>{inputField.loanType}</div>
    //       </div>
    //     </>
    //   )}
    // </>
  );
}

export default ApplyLoan;
