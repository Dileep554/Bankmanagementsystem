
import React, {useState} from "react";
import axios from "axios";
import {
  MDBContainer,
  MDBInput,
  MDBBtn
}
from 'mdb-react-ui-kit';

function Deposit(props) {
  const { userdata } = props
  const [inputField, setInputField] = useState({
    accountType: "",
    depositAmount: ""
  });

  const initialValues = {
    accountType: "",
    depositAmount: ""
  };
  

  const [amount, setAmount] = useState(0);


  const inputsHandler = (e) => {
    const { name, value } = e.target;
    setInputField((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };


  const submitButton = () => {
     console.log(inputField)

    axios
      .put(`http://localhost:8080/customer/depositAmount/${userdata.username}`, inputField)
      .then((data) => {
        console.log(data.data);
        setAmount(data.data);
        setInputField(initialValues);

      })
      .catch((error) => console.log(error));
  };
  return (
    <MDBContainer className="p-3 my-5 d-flex flex-column w-50" >

      <MDBInput wrapperClass='mb-4' placeholder='Account Type' id='form1' type='text' name="accountType" onChange={inputsHandler} value={inputField.accountType}/>
      <MDBInput wrapperClass='mb-4' placeholder='Deposit Amount' id='form2' type='text' name="depositAmount" onChange={inputsHandler} value={inputField.depositAmount}/>

      <MDBBtn className="mb-4" onClick={submitButton}>Deposit</MDBBtn>
      <div>
      {
        amount===0?(<></>):(<>Total Amount:{amount}</>)
      }
      </div>


    </MDBContainer>
  );
}

export default Deposit;