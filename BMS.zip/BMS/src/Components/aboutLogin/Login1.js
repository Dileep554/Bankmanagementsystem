import React, { useState } from "react";
import { MDBContainer, MDBInput, MDBCheckbox, MDBBtn } from "mdb-react-ui-kit";
import axios from "axios";
import { Link } from "react-router-dom";
import Profile from "../editProfileComponent/Profile";
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import Table from '@mui/material/Table';
import { TableHead } from "@mui/material";

function Login1(props) {
  const { authenticated, setAuthenticated, userdata, setUserdata } = props;
  const [inputField, setInputField] = useState({
    emailAddress: "",
    password: "",
  });

  const isDisabled =
    inputField.emailAddress.trim() == "" || inputField.password.trim() == "";

  const [errorMessage, setErrorMessage] = useState("")

  const inputsHandler = (e) => {
    const { name, value } = e.target;
    setInputField((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const submitButton = () => {
    // alert(inputField.username);
    //if(inputField.emailAddress.includes("@")
    axios
      .post("http://localhost:8080/customer/login", inputField)
      .then((data) => {
        console.log(data.data.status);
        setAuthenticated(data.data.status);
        setUserdata(data.data.customer);
        setInputField(inputField);
      })
      .catch((error) => {
        console.log(error)
        setErrorMessage(error.response.data.message)
      });
  };

  return (
    <div>
      {!authenticated ? (
        <><h1 className="bg bg-danger">{errorMessage}</h1>

        <Table className="w-50 text-center p-auto mx-auto border-0">
            <TableHead className="text-center">LOGIN</TableHead>
            <TableRow>
                <TableCell> <label>Email Address</label></TableCell>
                <TableCell>
                <input
                wrapperClass="mb-4"
                id="form1"
                name="emailAddress"
                onChange={inputsHandler}
                placeholder="Email Address"
                value={inputField.emailAddress}
                type="email"
                required
              />
                </TableCell>
            </TableRow>

            <TableRow>
                <TableCell><label>Password</label></TableCell>
                <TableCell><input
              wrapperClass="mb-4"
              id="form2"
              type="password"
              name="password"
              onChange={inputsHandler}
              placeholder="Password"
              value={inputField.password}
              required
            /></TableCell>
            </TableRow>

            <TableRow>
                <TableCell><MDBBtn
              className="mb-4"
              disabled={isDisabled}
              onClick={submitButton}
            >
              Sign in
            </MDBBtn></TableCell>
            </TableRow>

            <div className="text-center">
              <p>
                Not a member? <Link to={"/registerPage"}>Register</Link>
              </p>
            </div>
        </Table>
          {/* <MDBContainer className="p-3 my-5 d-flex flex-column w-50">
            <div className="d-flex">
              <div className="px-3 ">
              <label>Email Address</label>
              </div>
              <div className="px-3 mr-3">
              <MDBInput
                wrapperClass="mb-4"
                id="form1"
                name="emailAddress"
                onChange={inputsHandler}
                placeholder="Email Address"
                value={inputField.emailAddress}
                type="email"
                required
              />
              </div>
              </div> */}
{/*             
            <div className="d-flex">
              <div className="px-3 mr-4">
              <label>Password</label>
              </div>
              <div className="px-3">
            <MDBInput
              wrapperClass="mb-4"
              id="form2"
              type="password"
              name="password"
              onChange={inputsHandler}
              placeholder="Password"
              value={inputField.password}
              required
            />
            </div>
            </div> */}

            {/* <div className="d-flex justify-content-between mx-3 mb-4">
        <MDBCheckbox
          name="flexCheck"
          value=""
          id="flexCheckDefault"
          label="Remember me"
        />
        <a href="!#">Forgot password?</a>
      </div> */}

            {/* <MDBBtn
              className="mb-4"
              disabled={isDisabled}
              onClick={submitButton}
            >
              Sign in
            </MDBBtn>

            <div className="text-center">
              <p>
                Not a member? <Link to={"/registerPage"}>Register</Link>
              </p>
            </div>
          </MDBContainer> */}
        </>
      ) : (
        <>
          <h1>Welcome, {userdata.username}!</h1>
          <Profile userdata={userdata}/>
        </>
      )}
    </div>
  );
}

export default Login1;
