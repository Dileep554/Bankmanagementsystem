import React, {useEffect} from "react";
import axios from "axios";
import { useState } from "react";
import { MDBContainer, MDBInput, MDBBtn } from "mdb-react-ui-kit";
import SelectComponent from "../selectComponent/SelectComponent";

function Register() {
  const initialValues = {
    username: "",
    customerName: "",
    password: "",
    customerAddress: "",
    country: "",
    state: "",
    emailAddress: "",
    contactNumber: "",
    dateOfBirth: "",
    accountType: "",
    branchName: "",
    depositAmount: "",
    identificationProofType: "",
    identificationDocumentNo: ""}
  const [inputField, setInputField] = useState({
    username: "",
    customerName: "",
    password: "",
    customerAddress: "",
    country: "",
    state: "",
    emailAddress: "",
    contactNumber: "",
    dateOfBirth: "",
    accountType: "",
    branchName: "",
    depositAmount: "",
    identificationProofType: "",
    identificationDocumentNo: "",
  });

  const [amount, setAmount] = useState(0);
  const [accType, setAccType] = useState("");
  const allTypes = ["Salary","Savings"];

  const inputsHandler = (e) => {
    const { name, value } = e.target;
    setInputField((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  useEffect(() => {
    inputField.accountType = accType;
  }, [accType]);
  const submitButton = () => {
    alert(inputField.username);
    axios
      .post("http://localhost:8080/customer/register", inputField)
      .then((data) => {
        console.log(data.data);
       // event.target.reset();
        //setRegStatus("User Registered Successfully");
        setInputField(initialValues)
        setAmount(1);
      })
      .catch((error) => console.log(error));
  };
  return (
    <>
    <MDBContainer className="p-3 my-5 d-flex flex-column w-50">
      <MDBInput
        wrapperClass="mb-4"
        placeholder="Cutomer Name"
        id="form1"
        type="text"
        name="customerName"
        onChange={(e) => inputsHandler(e)}
        value={inputField.customerName}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form2"
        type="text"
        name="username"
        onChange={inputsHandler}
        placeholder="User Name"
        value={inputField.username}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form3"
        type="password"
        name="password"
        onChange={inputsHandler}
        placeholder="Password"
        value={inputField.password}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form4"
        type="text"
        name="customerAddress"
        onChange={inputsHandler}
        placeholder="Customer Address"
        value={inputField.customerAddress}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form5"
        type="text"
        name="country"
        onChange={inputsHandler}
        placeholder="Country"
        value={inputField.country}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form6"
        type="text"
        name="state"
        onChange={inputsHandler}
        placeholder="State"
        value={inputField.state}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form7"
        type="email"
        name="emailAddress"
        onChange={inputsHandler}
        placeholder="Email Address"
        value={inputField.emailAddress}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form8"
        type="tel"
        maxLength="10"
        name="contactNumber"
        onChange={inputsHandler}
        placeholder="Contact Number"
        value={inputField.contactNumber}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form9"
        type="date"
        name="dateOfBirth"
        onChange={inputsHandler}
        placeholder="Date Of Birth"
        value={inputField.dateOfBirth}
      />
      {/* <MDBInput
        wrapperClass="mb-4"
        id="form10"
        type="text"
        name="accountType"
        onChange={inputsHandler}
        placeholder="Account Type"
        value={inputField.accountType}
      /> */}
      <div className="mb-4">
      <SelectComponent 
          type={accType}
          setType={setAccType}
          allTypes={allTypes}
          labelType={"Account Type"}
        />
        </div>
      <MDBInput
        wrapperClass="mb-4"
        id="form11"
        type="text"
        name="branchName"
        onChange={inputsHandler}
        placeholder="Branch Name"
        value={inputField.branchName}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form12"
        type="text"
        name="depositAmount"
        onChange={inputsHandler}
        placeholder="Deposit Amount"
        value={inputField.depositAmount}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form13"
        type="text"
        name="identificationProofType"
        onChange={inputsHandler}
        placeholder="Identification Proof Type"
        value={inputField.identificationProofType}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form14"
        type="text"
        name="identificationDocumentNo"
        onChange={inputsHandler}
        placeholder="Identification Document No."
        value={inputField.identificationDocumentNo}
      />

      <MDBBtn className="mb-4" onClick={submitButton}>
        Sign in
      </MDBBtn>

      {/* <div>{(regStatus = "" ? <></> : <>{regStatus}</>)}</div> */}
      <div>
      {
        amount===0?(<></>):(<>User Registered Successfully</>)
      }
      </div>
      
    </MDBContainer>

    
    </>
  );
}

export default Register;
