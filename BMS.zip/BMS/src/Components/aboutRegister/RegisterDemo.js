import axios from "axios";
import { useState } from "react";
import "./Register.css";

export function RegisterDemo(){
    const [data, setData] = useState("mani");
  const [inputField, setInputField] = useState({
    username: "",
    customerName: "",
    password:"",
    customerAddress: "",
    country: "",
    state: "",
    emailAddress: "",
    contactNumber: "",
    dateOfBirth: "",
    accountType: "",
    branchName: "",
    depositAmount: 0,
    identificationProofType: "",
    identificationDocumentNo: "",
  });

  const inputsHandler = (e) => {
    const { name, value } = e.target;
    setInputField((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const submitButton = () => {
    alert(inputField.username);
    axios
      .post("http://localhost:8081/customer/register", inputField)
      .then((data) => {
        console.log(data.data);
      })
      .catch((error) => console.log(error));
  };

  const getCustomersData = () => {
    axios
      .get("http://localhost:8081/customer/hello")
      .then((data) => {
        console.log(data.data);
        setData(data.data);
      })
      .catch((error) => console.log(error));
  };

  //   axios
  //     .post("http://localhost:8081/customer/register", details)
  //     .then((data) => {
  //       console.log(data.data);
  //     })
  //     .catch((error) => console.log(error));
  // };

  // getCustomersData();

  return (
    <>
      <h1>{data}</h1>
      <button onClick={() => getCustomersData()}>click me</button>
      <div>
        <label>Name: </label>
        <input
          type="text"
          name="customerName"
          onChange={(e) => inputsHandler(e)}
          placeholder="Customer Name"
          value={inputField.customerName}
        />

        <br />
        <label>Username</label>
        <input
          type="text"
          name="username"
          onChange={inputsHandler}
          placeholder="User Name"
          value={inputField.username}
        />

        <br />
        <label>Password</label>
        <input
          type="text"
          name="password"
          onChange={inputsHandler}
          placeholder="Password"
          value={inputField.password}
        />

        <br />
        <label>Customer Address</label>
        <input
          type="text"
          name="customerAddress"
          onChange={inputsHandler}
          placeholder="Customer Address"
          value={inputField.customerAddress}
        />

        <br />
        <label>Country</label>
        <input
          type="text"
          name="country"
          onChange={inputsHandler}
          placeholder="Country"
          value={inputField.country}
        />

        <br />
        <label>State</label>
        <input
          type="text"
          name="state"
          onChange={inputsHandler}
          placeholder="State"
          value={inputField.state}
        />

        <br />
        <label>Email Address</label>
        <input
          type="email"
          name="emailAddress"
          onChange={inputsHandler}
          placeholder="Email Address"
          value={inputField.emailAddress}
        />

        <br />
        <label> Contact No.</label>
        <input
          type="text"
          name="contactNumber"
          onChange={inputsHandler}
          placeholder="Contact Number"
          value={inputField.contactNumber}
        />

        <br />
        <label>Date Of Birth</label>
        <input
          type="date"
          name="dateOfBirth"
          onChange={inputsHandler}
          placeholder="Date Of Birth"
          value={inputField.dateOfBirth}
        />

        <br />
        <label>Account Type</label>
        <input
          type="text"
          name="accountType"
          onChange={inputsHandler}
          placeholder="Account Type"
          value={inputField.accountType}
        />

        <br />
        <label>Branch Name</label>
        <input
          type="text"
          name="branchName"
          onChange={inputsHandler}
          placeholder="Branch Name"
          value={inputField.branchName}
        />

        <br />
        <label>Deposit Amount</label>
        <input
          type="text"
          name="depositAmount"
          onChange={inputsHandler}
          placeholder="Deposit Amount"
          value={inputField.depositAmount}
        />

        <br />
        <label>identification Proof Type</label>
        <input
          type="text"
          name="identificationProofType"
          onChange={inputsHandler}
          placeholder="Identification Proof Type"
          value={inputField.identificationProofType}
        />

        <br />
        <label>Identification Document No.</label>
        <input
          type="text"
          name="identificationDocumentNo"
          onChange={inputsHandler}
          placeholder="Identification Document No."
          value={inputField.identificationDocumentNo}
        />

        <br />

        <button onClick={submitButton}>Submit Now</button>
      </div>
    </>
  );
}

export default RegisterDemo;