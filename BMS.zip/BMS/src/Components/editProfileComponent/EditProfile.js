import React from "react";
import axios from "axios";
import { useState } from "react";
import { MDBContainer, MDBInput, MDBBtn } from "mdb-react-ui-kit";
import Profile from "../editProfileComponent/Profile";

function EditProfile(props) {
  const { authenticated, setAuthenticated, userdata,setUserdata } = props;
  const initialValues = {
    username: "",
    customerName: "",
    password:"",
    customerAddress: "",
    country: "",
    state: "",
    emailAddress: "",
    contactNumber: "",
    dateOfBirth: "",
    accountType: "",
    branchName: "",
    depositAmount: "",
    identificationProofType: "",
    identificationDocumentNo: ""}
  const [inputField, setInputField] = useState(userdata);

  const [amount, setAmount] = useState(0);

  const inputsHandler = (e) => {
    const { name, value } = e.target;
    setInputField((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const submitButton = () => {
    alert(inputField.username);
    axios
      .put(`http://localhost:8080/customer/updateCustomer/${userdata.username}`, inputField)
      .then((data) => {
        console.log(data.data);
       // event.target.reset();
        //setRegStatus("User Registered Successfully");
        setUserdata(data.data)
        setInputField(initialValues)
        setAmount(1);
      })
      .catch((error) => console.log(error));
  };
  return (
    <>
    
    {amount==0 ? (<>
    <div>
      <h3 className="text-center pt-2">Edit Profile</h3>
    </div>
    <MDBContainer className="pt-4 my-5 d-flex flex-column w-50">
      <MDBInput
        wrapperClass="mb-4"
        placeholder="Cutomer Name"
        id="form1"
        type="text"
        name="customerName"
        onChange={(e) => inputsHandler(e)}
        value={inputField.customerName}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form2"
        type="text"
        name="username"
        onChange={inputsHandler}
        placeholder="User Name"
        value={inputField.username}
        disabled
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form3"
        type="password"
        name="password"
        onChange={inputsHandler}
        placeholder="Password"
        value={inputField.password}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form4"
        type="text"
        name="customerAddress"
        onChange={inputsHandler}
        placeholder="Customer Address"
        value={inputField.customerAddress}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form5"
        type="text"
        name="country"
        onChange={inputsHandler}
        placeholder="Country"
        value={inputField.country}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form6"
        type="text"
        name="state"
        onChange={inputsHandler}
        placeholder="State"
        value={inputField.state}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form7"
        type="email"
        name="emailAddress"
        onChange={inputsHandler}
        placeholder="Email Address"
        value={inputField.emailAddress}
        disabled
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form8"
        type="tel"
        maxLength="10"
        name="contactNumber"
        onChange={inputsHandler}
        placeholder="Contact Number"
        value={inputField.contactNumber}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form9"
        type="date"
        name="dateOfBirth"
        onChange={inputsHandler}
        placeholder="Date Of Birth"
        value={inputField.dateOfBirth}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form10"
        type="text"
        name="accountType"
        onChange={inputsHandler}
        placeholder="Account Type"
        value={inputField.accountType}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form11"
        type="text"
        name="branchName"
        onChange={inputsHandler}
        placeholder="Branch Name"
        value={inputField.branchName}
      />

      <MDBInput
        wrapperClass="mb-4"
        id="form13"
        type="text"
        name="identificationProofType"
        onChange={inputsHandler}
        placeholder="Identification Proof Type"
        value={inputField.identificationProofType}
      />
      <MDBInput
        wrapperClass="mb-4"
        id="form14"
        type="text"
        name="identificationDocumentNo"
        onChange={inputsHandler}
        placeholder="Identification Document No."
        value={inputField.identificationDocumentNo}
      />

      <MDBBtn className="mb-4" onClick={submitButton}>
        Save
      </MDBBtn>
      </MDBContainer>
      </>
      ):
        (<><Profile userdata={userdata}/></>)
    }
      </>
    
    
  );
}

export default EditProfile;
