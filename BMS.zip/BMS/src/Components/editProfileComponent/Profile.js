import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import "./Profile.css";
import EditIcon from '@mui/icons-material/Edit';
import EditProfile from "./EditProfile";
import { Link } from "react-router-dom";


export default function Profile(props) {
    const { userdata,authenticated } = props;
  return (
      <>
      <div className="mx-8">
          <h3 className="mx-3 text-center">Profile Information  <Link to={"/editProfilePage"}><EditIcon authenticated={authenticated} userdata={userdata} /></Link>
          {/* <a href="/editProfilePage" authenticated={authenticated}><EditIcon /></a> */}
          </h3>
      </div>
    <TableContainer component={Paper} className="w-50 p-auto text-center mx-auto">
      <Table sx={{ minWidth: 500 }} aria-label="simple table">
        <TableBody>
            <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>{userdata.customerName}</TableCell>
            </TableRow>
            <TableRow>
                <TableCell>Username</TableCell>
                <TableCell>{userdata.username}</TableCell>
            </TableRow>
            <TableRow>
                <TableCell>Email</TableCell>
                <TableCell>{userdata.emailAddress}</TableCell>
            </TableRow>
            <TableRow>
                <TableCell>Phone No.</TableCell>
                <TableCell>{userdata.contactNumber}</TableCell>
            </TableRow>
            <TableRow>
                <TableCell>Date Of Birth</TableCell>
                <TableCell>{userdata.dateOfBirth}</TableCell>
            </TableRow>
            <TableRow>
                <TableCell>Address</TableCell>
                <TableCell>{userdata.customerAddress}</TableCell>
            </TableRow>
            <TableRow>
                <TableCell>Country</TableCell>
                <TableCell>{userdata.country}</TableCell>
            </TableRow>
            <TableRow>
                <TableCell>State</TableCell>
                <TableCell>{userdata.state}</TableCell>
            </TableRow>
            <TableRow>
                <TableCell>Branch Name</TableCell>
                <TableCell>{userdata.customerName}</TableCell>
            </TableRow>
            <TableRow>
                <TableCell>Identification Type</TableCell>
                <TableCell>{userdata.identificationProofType}</TableCell>
            </TableRow>
            <TableRow>
                <TableCell>Identification No.</TableCell>
                <TableCell>{userdata.identificationDocumentNo}</TableCell>
            </TableRow>
            <TableRow>
                <TableCell>Account Type</TableCell>
                <TableCell>{userdata.accountType}</TableCell>
            </TableRow>
        </TableBody>
      </Table>
    </TableContainer>
    </>
  );
}
