import React,{useState} from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import { Link } from "react-router-dom";



//import IconButton from '@mui/material/IconButton';
//import MenuIcon from '@mui/icons-material/Menu';

export default function HeaderComponent(props) {
  const {authenticated, setAuthenticated, userdata} = props;
  
  const logoutButton = () => {
    // alert(inputField.username);
    //if(inputField.emailAddress.includes("@")
    setAuthenticated(false);
  };
  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          {/* <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton> */}
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Bank Management System
          </Typography>
          {!authenticated?
          <>
            <Link to={"/loginPage"}>

            <Button color="inherit" className="text-white">Login
          </Button></Link>
          <Link to={"/registerPage"}><Button color="inherit" className="text-white">Register</Button></Link>
          </>:
          <>
          <Link to={"/profilePage"}><Button color="inherit" className="text-white ml-5">My Profile</Button></Link>
          
          <Link to={"/applyLoanPage"}><Button color="inherit" className="bg bg-blue text-white ml-5" userdata={userdata}>Apply Loan</Button></Link>
          <Link to={"/depositPage"}><Button color="inherit" className="text-white ml-5">Deposit Amount</Button></Link>
          <Link to={"/"}><Button color="inherit" className="text-white ml-5" onClick={logoutButton}>Logout</Button></Link>
          </>
          }
          
          

        </Toolbar>
      </AppBar>
    </Box>
  );
}
