package com.bms.customer.controller;

import com.bms.customer.exception.*;
import com.bms.customer.model.Customer;
import com.bms.customer.response.LoginResponse;
import com.bms.customer.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:3000")
public class CustomerController {


    @Autowired
    CustomerService customerService;


    @GetMapping("/hello")
    public ResponseEntity<?> hello(){
                return new ResponseEntity<String>("hello", HttpStatus.OK);

    }

    @PostMapping("/register")
    public ResponseEntity<Customer> registerCustomer(@RequestBody Customer customer ) throws UserExistsException{
        Optional<Customer> cust;
        cust = Optional.ofNullable(customerService.registerCustomer(customer));
        return new ResponseEntity<Customer>(customer, HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> loginCustomer(@RequestBody Customer customer) throws UserNotFoundException, PasswordIncorrectException, InvalidFieldException {

        Customer res = customerService.loginCustomer(customer.getEmailAddress(), customer.getPassword());
        LoginResponse resp = new LoginResponse(res, true);
        return new ResponseEntity<LoginResponse>(resp, HttpStatus.CREATED);

    }

    @PutMapping("/updateCustomer/{username}")
    public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer, @PathVariable("username") String username) throws UserNotFoundException{
        customerService.updateCustomer(customer,username);
        return new ResponseEntity<Customer>(customer, HttpStatus.OK);
    }

    @GetMapping("/allUsers")
    public ResponseEntity<List<Customer>> allCustomers(){
        List<Customer> customers = customerService.allCustomers();

        return new ResponseEntity<>(customers,HttpStatus.OK);
    }

    @GetMapping("/userByName/{username}")
    public ResponseEntity<Customer> getUserByUsername(@PathVariable("username") String username) throws UserNotFoundException{
        Customer customer = customerService.getUserByUsername(username);

        return new ResponseEntity<>(customer,HttpStatus.OK);
    }

    @PutMapping("/depositAmount/{username}")
    public ResponseEntity<Long> depositAmount(@PathVariable("username") String username,@RequestBody Customer customer) throws AccountTypeException, UserNotFoundException {

        long amount = customerService.depositAmount(username,customer.getAccountType(),customer.getDepositAmount());
            return new ResponseEntity<>(amount,HttpStatus.OK);


    }


}
