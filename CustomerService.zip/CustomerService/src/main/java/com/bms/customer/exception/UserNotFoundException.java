package com.bms.customer.exception;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(code = HttpStatus.CONFLICT, reason = "User Not Found")
public class UserNotFoundException extends Exception {
//    String message;
//    public UserNotFoundException(String msg) {
//        this.message=msg;
//    }
//    public UserNotFoundException(){
//
//    }
}
