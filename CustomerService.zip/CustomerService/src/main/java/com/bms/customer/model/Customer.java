package com.bms.customer.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.Past;
import java.sql.Date;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customerId;
    
    @Column(nullable = false,unique = true)
    private String username;
    private String customerName;
    private String password;
    private String customerAddress;
    private String country;
    private String state;
    @Column(nullable = false,unique = true)
    @Valid
    private String emailAddress;
    private String contactNumber;
    @Past
    private Date dateOfBirth;
    private String accountType;
    private String branchName;
    private long depositAmount;
    private String identificationProofType;
    private String identificationDocumentNo;
//
//    public Customer() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	public Customer(Long customerId, String username, String customerName, String password, String customerAddress,
//			String country, String state, @Valid String emailAddress, String contactNumber, @Past Date dateOfBirth,
//			String accountType, String branchName, long depositAmount, String identificationProofType,
//			String identificationDocumentNo) {
//		super();
//		this.customerId = customerId;
//		this.username = username;
//		this.customerName = customerName;
//		this.password = password;
//		this.customerAddress = customerAddress;
//		this.country = country;
//		this.state = state;
//		this.emailAddress = emailAddress;
//		this.contactNumber = contactNumber;
//		this.dateOfBirth = dateOfBirth;
//		this.accountType = accountType;
//		this.branchName = branchName;
//		this.depositAmount = depositAmount;
//		this.identificationProofType = identificationProofType;
//		this.identificationDocumentNo = identificationDocumentNo;
//	}
//
//	public Long getCustomerId() {
//		return customerId;
//	}
//	public void setCustomerId(Long customerId) {
//		this.customerId = customerId;
//	}
//	public String getUsername() {
//		return username;
//	}
//	public void setUsername(String username) {
//		this.username = username;
//	}
//	public String getCustomerName() {
//		return customerName;
//	}
//	public void setCustomerName(String customerName) {
//		this.customerName = customerName;
//	}
//	public String getPassword() {
//		return password;
//	}
//	public void setPassword(String password) {
//		this.password = password;
//	}
//	public String getCustomerAddress() {
//		return customerAddress;
//	}
//	public void setCustomerAddress(String customerAddress) {
//		this.customerAddress = customerAddress;
//	}
//	public String getCountry() {
//		return country;
//	}
//	public void setCountry(String country) {
//		this.country = country;
//	}
//	public String getState() {
//		return state;
//	}
//	public void setState(String state) {
//		this.state = state;
//	}
//	public String getEmailAddress() {
//		return emailAddress;
//	}
//	public void setEmailAddress(String emailAddress) {
//		this.emailAddress = emailAddress;
//	}
//	public String getContactNumber() {
//		return contactNumber;
//	}
//	public void setContactNumber(String contactNumber) {
//		this.contactNumber = contactNumber;
//	}
//	public Date getDateOfBirth() {
//		return dateOfBirth;
//	}
//	public void setDateOfBirth(Date dateOfBirth) {
//		this.dateOfBirth = dateOfBirth;
//	}
//	public String getAccountType() {
//		return accountType;
//	}
//	public void setAccountType(String accountType) {
//		this.accountType = accountType;
//	}
//	public String getBranchName() {
//		return branchName;
//	}
//	public void setBranchName(String branchName) {
//		this.branchName = branchName;
//	}
//	public long getDepositAmount() {
//		return depositAmount;
//	}
//	public void setDepositAmount(long depositAmount) {
//		this.depositAmount = depositAmount;
//	}
//	public String getIdentificationProofType() {
//		return identificationProofType;
//	}
//	public void setIdentificationProofType(String identificationProofType) {
//		this.identificationProofType = identificationProofType;
//	}
//	public String getIdentificationDocumentNo() {
//		return identificationDocumentNo;
//	}
//	public void setIdentificationDocumentNo(String identificationDocumentNo) {
//		this.identificationDocumentNo = identificationDocumentNo;
//	}
	


}
