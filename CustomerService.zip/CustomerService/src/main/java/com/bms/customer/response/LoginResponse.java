package com.bms.customer.response;

import com.bms.customer.model.Customer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class LoginResponse {

    
	private Customer customer;
    private Boolean status;
    
//    public LoginResponse() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	public LoginResponse(Customer customer, Boolean status) {
//		super();
//		this.customer = customer;
//		this.status = status;
//	}
//
//	public Customer getCustomer() {
//		return customer;
//	}
//
//	public void setCustomer(Customer customer) {
//		this.customer = customer;
//	}
//
//	public Boolean getStatus() {
//		return status;
//	}
//
//	public void setStatus(Boolean status) {
//		this.status = status;
//	}
    

}
