package com.bms.customer.service;

import com.bms.customer.exception.*;
import com.bms.customer.model.Customer;
import com.bms.customer.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository custRepo;

    public Customer registerCustomer(Customer customer) throws UserExistsException {

        if(checkUsername(customer.getUsername())){
            throw new UserExistsException();
        }

        custRepo.save(customer);
        Customer customer1 = custRepo.findByUsername(customer.getUsername());
        return customer1;

    }

    public boolean isCustomerPresent(String username){
        List<Customer> allCustomers = custRepo.findAll();
        for(Customer c:allCustomers){
            if(c.getUsername()==username){
                return false;
            }
        }
        return false;

    }

    public boolean checkUsername(String id) {

        Boolean x = false;
        List<Customer> m = (List<Customer>) custRepo.findAll();
        for (Customer i : m) {
            if (i.getUsername().equals(id)) {
                x = true;
                break;
            }
        }
        return x;

    }
    public boolean checkEmailId(String emailId) {

        Boolean x = false;
        List<Customer> u = (List<Customer>) custRepo.findAll();
        for (Customer i : u) {
            if (i.getEmailAddress().equals(emailId)) {
                x = true;
                break;
            }
        }
        return x;

    }

    public void updateCustomer(Customer customer, String username) throws UserNotFoundException{

        Customer c = custRepo.findByUsername(username);
        custRepo.delete(c);
        custRepo.save(customer);

    }

    public Customer findById(String username) throws UserNotFoundException{
        //List<Customer> customers = custRepo.findAll();
        //return (Customer) customers.stream().filter(c->c.getUsername().equals(username));
        List<Customer> allCustomers = custRepo.findAll();
        for(Customer c:allCustomers){
            if(c.getUsername().equals(username)){
                return c;
            }
        }
        throw new UserNotFoundException();
    }

    public List<Customer> allCustomers() {
        return custRepo.findAll();
    }

    public Customer loginCustomer(String emailAddress, String password) throws UserNotFoundException, PasswordIncorrectException, InvalidFieldException {
        if(emailAddress.equals("")||password.equals("")) {
            throw new InvalidFieldException();
        }
        List<Customer> customers = custRepo.findAll();
        for (Customer c : customers) {

            if (c.getEmailAddress().equals(emailAddress) && c.getPassword().equals(password)) {
                return c;
            }
            else if(c.getEmailAddress().equals(emailAddress) && !c.getPassword().equals(password)){
                throw new PasswordIncorrectException();
            }

        }
        throw new UserNotFoundException();


    }


    public Customer getUserByUsername(String username) throws UserNotFoundException{
        return findById(username);
    }

    public long depositAmount(String username, String accountType, long depositAmount) throws AccountTypeException, UserNotFoundException {
        Customer c = findById(username);
        if(c.getAccountType().equals(accountType)){
            custRepo.delete(c);
            long amount = depositAmount+c.getDepositAmount();
            c.setDepositAmount(amount);
            custRepo.save(c);
            return amount;

        }

        throw new AccountTypeException();
    }
}
