package com.bms.customer.service;

import static org.junit.jupiter.api.Assertions.*;

import com.bms.customer.model.Customer;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.bms.customer.controller.CustomerController;
import com.bms.customer.repository.CustomerRepository;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

class CustomerServiceTest {

	@InjectMocks
	CustomerService customerService;
	
	@Mock 
	CustomerRepository customerRepository;
	
	@Test
	void testisCustomerPresent() {
		String name="abc123";
		boolean res=customerService.isCustomerPresent(name);
		
		//when(customerRepository.findAll()).thenReturn()
		//assertEquals(false,res);
		//assertNull(res);
		List<Customer> allCustomers = new ArrayList<>();
		//Customer c = new Customer(1,"mani","maneesha","sai","plkd","india","AP","mani@gmail.com",new Date[],"savings","plkd",2000,);
		//allCustomers.add();
		//customer
	}

}
