package com.bms.loan.controller;

import com.bms.loan.model.LoanDetails;
import com.bms.loan.service.LoanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/applyLoan")
@CrossOrigin
public class LoanController {

    @Autowired
    LoanService loanService;

    @PostMapping("/{customerId}")
    public ResponseEntity<String> applyLoan(@RequestBody LoanDetails loanDetails, @PathVariable("customerId") Long customerId){

            loanService.applyLoan(customerId,loanDetails);

        return new ResponseEntity<>("Loan applied successfully", HttpStatus.CREATED);

    }

    @GetMapping("/allLoans")
    public ResponseEntity<List<LoanDetails>> getAllLoans(){

        List<LoanDetails> loans = loanService.getAllLoans();

        return new ResponseEntity<List<LoanDetails>>(loans, HttpStatus.CREATED);

    }


    @GetMapping("/allLoans/{customerId}")
    public ResponseEntity<List<LoanDetails>> getAllLoansById(@PathVariable("customerId") Long customerId){

        List<LoanDetails> loans = loanService.getAllLoansById(customerId);

        return new ResponseEntity<List<LoanDetails>>(loans, HttpStatus.CREATED);

    }


}
