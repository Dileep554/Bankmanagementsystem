package com.bms.loan.model;


import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@NoArgsConstructor
@Setter
@AllArgsConstructor
@ToString
public class LoanDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long loanId;
    private Long customerId;
    private String loanType;
    private long loanAmount;
    private Date date;
    private float rateOfInterest;
    private int durationOfLoan;

    @Embedded
    private LoanInformation loanInformation;


}
