package com.bms.loan.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;

@Embeddable
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class LoanInformation {

    private double courseFee;
    private String course;
    private String fatherName;
    private String fatherOccupation;
    private String fatherAnnualIncome;
    private double annualIncome;
    private String companyName;
    private String Designation;
    private int totalExp;
    private int currentCompanyExp;
}
