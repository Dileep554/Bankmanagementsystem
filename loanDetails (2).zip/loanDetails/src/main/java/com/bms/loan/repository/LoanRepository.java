package com.bms.loan.repository;

import com.bms.loan.model.LoanDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LoanRepository extends JpaRepository<LoanDetails,Long> {

    List<LoanDetails> findByCustomerId(Long customerId);

}
