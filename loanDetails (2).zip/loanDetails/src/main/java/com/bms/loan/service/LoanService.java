package com.bms.loan.service;

import com.bms.loan.model.LoanDetails;
import com.bms.loan.repository.LoanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanService {

    @Autowired
    LoanRepository loanRepo;

    public void applyLoan(Long customerId, LoanDetails loanDetails){
        loanDetails.setCustomerId(customerId);
        loanRepo.save(loanDetails);
    }

    public List<LoanDetails> getAllLoans() {
        return loanRepo.findAll();
    }

    public List<LoanDetails> getAllLoansById(Long customerId) {
        return loanRepo.findByCustomerId(customerId);
    }
}
