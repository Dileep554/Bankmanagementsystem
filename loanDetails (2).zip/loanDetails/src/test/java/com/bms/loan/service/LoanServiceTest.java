package com.bms.loan.service;

import com.bms.loan.model.LoanDetails;
import com.bms.loan.repository.LoanRepository;
import org.junit.jupiter.api.Assertions;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class LoanServiceTest {


    @Mock
    LoanRepository loanRepo;

    @InjectMocks
    LoanService loanService;

    public void getLoanTest(){

        int cId = 2;
        //LoanDetails loan = new LoanDetails()
//        loanService.getAllLoansById((long) cId);
        assertThat(loanService.getAllLoansById((long) cId)).isNull();
    }

}